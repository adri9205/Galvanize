﻿namespace ContosoPets.Domain.DataTransferObjects
{
    public class OrderLineItem
    {
        public int ProductQuantity { get; set; }
        public string ProductName { get; set; }
    }
}
